//
//  FlattenArray.playground
//
//  Created by michael dunn on 2/9/19.
//  Copyright © 2019 michael dunn. All rights reserved.
//


///
/// Generic array extension to flatten array of an array of arbitrarily nested arrays of a given Type
///

extension Array {
    
    func flatten<Element>() -> [Element] {
        
        // check if array is already a single level of Element
        
        if let elementArray = self as? [Element] {
            return elementArray
        }
        
        
        // iterate over each item
        // if the item is of type Element or [Element] add to results
        // if the item is of type [Any] add flatten(item) to results
        // if the item is neither type of Element, [Element] or [Any] then ignore
        
        var result: [Element] = []
        
        forEach {
            switch $0 {
            case let elementA as Element:
                result.append(elementA)
            case let elementArray as [Element]:
                result.append(contentsOf: elementArray)
            case let anyArray as [Any]:
                result.append(contentsOf: anyArray.flatten())
            default:
                // ignore unsupported element
                break
            }
        }
        return result
    }
}


func flattenInts(_ arr: [Any]) ->  [Int] {
    return arr.flatten()
}

//
// Test Cases
//


assert( ([].flatten() as [Int]) == [] )
assert( flattenInts([]) == [] )

assert( ([1].flatten() as [Int]) == [1] )
assert( flattenInts([1]) == [1] )

assert( ([1,[2]].flatten() as [Int]) == [1,2] )
assert( flattenInts([1,[2]]) == [1,2] )

assert( ([1,[2],3].flatten() as [Int]) == [1,2,3] )
assert( flattenInts([1,[2],3]) == [1,2,3] )

assert( ([1,[2],[3,[[[[4]]]]]].flatten() as [Int]) == [1,2,3,4] )
assert( flattenInts([1,[2],3,[[[[4]]]]]) == [1,2,3,4] )

assert( ([[[[[[0,1,[2],[3,[[[[4]]]],5,6],7,[8]]]]],Int.max]].flatten() as [Int]) == [0,1,2,3,4,5,6,7,8,Int.max] )
assert( flattenInts([[[[[[0,1,[2],[3,[[[[4]]]],5,6],7,[8]]]]],Int.max]]) == [0,1,2,3,4,5,6,7,8,Int.max] )

assert( ([[-3,-2,[[-1,[Int.min,[0,1,[2],[3,[[[[4]]]],5,6],7,[8]]]],9,10,[11,12]],Int.max],13,14].flatten() as [Int]) == [-3,-2,-1,Int.min,0,1,2,3,4,5,6,7,8,9,10,11,12,Int.max,13,14] )
assert( flattenInts([[[[[[0,1,[2],[3,[[[[4]]]],5,6],7,[8]]]],9,10,[11,12]],Int.max],13,14]) == [0,1,2,3,4,5,6,7,8,9,10,11,12,Int.max,13,14] )


//
// Tester Class for generating random nested arrays with incrementing integers
//
class Tester {
    
    var index: Int = 0
    var results: [Int] = []
    
    var nextItem: Int {
        let i = index
        index += 1
        return i
    }
    
    func createSubArray(_ level: UInt) -> [Any] {
        var result: [Any] = []
        let preItems = Int.random(in: 0...4)
        for _ in 0..<preItems {
            result.append(nextItem)
        }
        if level == 0 {
            if result.isEmpty {
                result.append(nextItem)
            }
            return result
        }
        else {
            result.append(createSubArray(level-1))
        }
        let postItems = Int.random(in: 0...2)
        for _ in 0..<postItems {
            result.append(nextItem)
        }
        if result.isEmpty {
            result.append(nextItem)
        }
        return result
    }
    
    func reset() {
        index = 0
    }
}

//
// perform random number of tests on random arrays of integers
//

func randomTest(seed: Int) {
    let tester = Tester()
    for _ in 0..<Int.random(in: 1...seed) {
        tester.reset()
        let level = UInt.random(in: 1...50)
        let testArray = tester.createSubArray(level)
        let resultArray: [Int] = Array(ContiguousArray(0..<tester.index))
        print(testArray)
        print(resultArray.count)
        assert(testArray.flatten() == resultArray)
        assert(flattenInts(testArray) == resultArray)
    }
}
randomTest(seed: 30)

//
// Non-integer array
//

var c1: [Any] = ["ab","d",[[[[[["e","f"]],10],"g",30]]],"hi","j",[[["k"]]]]
assert( (c1.flatten() as [String]) == ["ab","d","e","f","g","hi","j","k"] )
assert( (c1.flatten() as [Int]) == [10,30])

let ca: [Character] = ["a","b","x","y"]
c1.append(contentsOf: ca)
assert(c1.flatten() as [Character] ==  ca)
